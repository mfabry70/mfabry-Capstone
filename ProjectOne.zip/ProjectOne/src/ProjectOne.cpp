//============================================================================
// Name        : ProjectOne.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

/* Header Inclusions */
#include <iostream>
#include <GL/glew.h>
#include <GL/freeglut.h>

//GLM Math Header inclusions
#include <GL/glm/glm/glm.hpp>
#include <GL/glm/glm/gtc/matrix_transform.hpp>
#include <GL/glm/glm/gtc/type_ptr.hpp>

#include "SOIL2/SOIL2.h"

using namespace std; //standard namespace

#define WINDOW_TITLE "Final Project" //window title macro

/*Shader program macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version "\n" #Source
#endif


/*Variable declarations for shader, window size initialization, buffer and array objects*/
GLint shaderProgram, fillShaderProgram, keyShaderProgram, WindowWidth = 800, WindowHeight = 600;
GLuint VBO, VAO, EBO, FillLightVAO, KeyLightVAO, texture;
GLfloat degrees = glm::radians(-45.0f); //converts float to degrees

GLfloat cameraSpeed = 0.0005f; //movement speed per frame


GLfloat lastMouseX = 400, lastMouseY = 300; //locks mouse cursor at the center of the screen
GLfloat mouseXOffset, mouseYOffset, yaw = 0.0f, pitch = 0.0f; //mouse offset, yaw, and pitch variables
GLfloat sensitivity = 0.005f; //used for mouse / camera rotation sensitivity
bool mouseDetected = true; //initially true when mouse movement is detected

//Global vector declarations
glm::vec3 cameraPosition = glm::vec3(0.0f, 0.0f, 0.0f); //initial camera position.  Placed 5 units in Z
glm::vec3 CameraUpY = glm::vec3(0.0f, 1.0f, 0.0f); //temporary y unit vector
glm::vec3 CameraForwardZ = glm::vec3(0.0f, 0.0f, -1.0f); //temporary z unit vector
glm::vec3 front; //temporary z unit vector for mouse

//Object color
glm::vec3 objectColor(0.6f, 0.5f, 0.75f);
glm::vec3 fillLightColor(1.0f, 1.0f, 1.0f);
glm::vec3 keyLightColor(0.0f, 1.0f, 0.0f);

// Light position and scale
glm::vec3 fillLightPosition(0.7f, 0.0f, 0.0f);
glm::vec3 fillLightScale(0.3f);
glm::vec3 keyLightPosition(-0.7f, 0.4f, 0.2f);
glm::vec3 keyLightScale(0.4f);


/*Function prototypes*/
void UResizeWindow(int, int);
void URenderGraphics(void);
void UCreateShader(void);
void UCreateBuffers(void);
void UGenerateTexture(void);
void UMouseMove(int x, int y);

/*Vertex Shader Source code*/
const GLchar * vertexShaderSource = GLSL(330,
	layout (location = 0) in vec3 position; //vertex data from vertex attrib pointer 0
	layout (location = 1) in vec3 color; //color data from vertex attrib pointer 1
	layout (location = 2) in vec2 textureCooridates

	out vec2 mobileTextureCoordinate; // Output the texture coordinate data to fragment shader
	out vec3 Normal; // Output normal to fragment shader
	out vec3 FragmentPos; // For outgoing color/pixels to fragment shader


	//Global variables for the transform matrices
	uniform mat4 model;
	uniform mat4 view;
	uniform mat4 projection;

void main(){
	gl_Position = projection * view * model * vec4(position, 1.0f); // transform vertices to clip coordinates
	mobileTextureCoordinate = vec2(textureCoordinate.x, 1.0f - textureCoordinate.y); // Flip the texture horizontally
	FragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment/pixel position in world space
	Normal = mat3(transpose(inverse(model))) * normal; // Gets normal vectors in world space
	}
);


/* Fragment Shader Source Code*/
const GLchar* pyramidFragmentShaderSource = GLSL(330,
	in vec2 mobileTextureCoordinate;
	in vec3 Normal;
	in vec3 FragmentPos;

	out vec4 pyramidColor; // Store the data to send to GPU

	uniform sampler2D uTexture;
	uniform vec3 fillLightColor;
	uniform vec3 fillLightPosition;
	uniform vec3 keyLightColor;
	uniform vec3 keyLightPosition;
	uniform vec3 viewPosition;

	void main() {

		/* Phong lighting model calculations */
		vec3 norm = normalize(Normal); // Normalize vectors to 1 unit
		vec3 viewDir = normalize(viewPosition - FragmentPos); // Calculate view direction
		// Ambient lighting
		float fillAmbientStrength = 0.3f; // Set ambient lighting strength
		vec3 fillAmbient = fillAmbientStrength * fillLightColor; // Generate ambient light color

		// Diffuse lighting
		vec3 fillLightDirection = normalize(fillLightPosition - FragmentPos); // Calculate distance between light source and fragment
		float fillImpact = max(dot(norm, fillLightDirection), 0.0); // Calculate diffuse impact by generating dot product of normal and light
		vec3 fillDiffuse = fillImpact * fillLightColor; // Diffuse light color

		//Specular lighting
		float fillSpecularIntensity = 0.8f; // Specular light strength
		float fillHighlightSize = 16.0f; // Specular highlight size

		vec3 fillReflectDir = reflect(-fillLightDirection, norm); // Calculate reflection vector
		float fillSpecularComponent = pow(max(dot(viewDir, fillReflectDir), 0.0), fillHighlightSize);
		vec3 fillSpecular = fillSpecularIntensity * fillSpecularComponent * fillLightColor;

		// Ambient lighting
		float keyAmbientStrength = 0.1f; // Set ambient lighting strength
		vec3 keyAmbient = keyAmbientStrength * keyLightColor; // Generate ambient light color

		// Diffuse lighting
		vec3 keyLightDirection = normalize(keyLightPosition - FragmentPos); // Calculate distance between light source and fragment
		float keyImpact = max(dot(norm, keyLightDirection), 0.1); // Calculate diffuse impact by generating dot product of normal and light
		vec3 keyDiffuse = keyImpact * keyLightColor; // Diffuse light color

		//Specular lighting
		float keySpecularIntensity = 0.8f; // Specular light strength
		float keyHighlightSize = 16.0f; // Specular highlight size

		vec3 keyReflectDir = reflect(-keyLightDirection, norm); // Calculate reflection vector
		float keySpecularComponent = pow(max(dot(viewDir, keyReflectDir), 0.0), keyHighlightSize);
		vec3 keySpecular = keySpecularIntensity * keySpecularComponent * keyLightColor;

		// Phong result
		vec3 objectColor = texture(uTexture, mobileTextureCoordinate).xyz;
		vec3 phong = (fillAmbient + keyAmbient + fillDiffuse + keyDiffuse) * objectColor + fillSpecular + keySpecular;
		pyramidColor = vec4(phong, 1.0f); // Send lit texture data to GPU for rendering
	}
);

// Fill light vertex shader
const GLchar *fillVertexShaderSource = GLSL(330,
	layout (location=0) in vec3 position; // Position 0 for vertex position data

	uniform mat4 model;
	uniform mat4 view;
	uniform mat4 projection;

	void main() {
		gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
	}
);

// Fill light fragment shader
const GLchar *fillFragmentShaderSource = GLSL(330,
	out vec4 color; // For outgoing lamp color to the GPU

	void main() {
		color = vec4(1.0f, 0.0f, 0.0f, 1.0f); // Sets light color to white with alpha of 0.1f
	}
);

// Key light vertex shader
const GLchar *keyVertexShaderSource = GLSL(330,
	layout (location=0) in vec3 position; // Position 0 for vertex position data

	uniform mat4 model;
	uniform mat4 view;
	uniform mat4 projection;

	void main() {
		gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
	}
);

// Key light fragment shader
const GLchar *keyfragmentShaderSource = GLSL(330,
	out vec4 color; // For outgoing lamp color to the GPU

	void main() {
		color = vec4(0.0f, 1.0f, 0.0f, 1.0f); // Sets light color to white with alpha of 0.1f
	}
);

/*Main Program*/
int main(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowSize(WindowWidth, WindowHeight);
	glutCreateWindow(WINDOW_TITLE);

	glutReshapeFunc(UResizeWindow);


	glewExperimental = GL_TRUE;
			if (glewInit() != GLEW_OK)
			{
				std::cout << "Failed to initialize GLEW" << std::endl;
				return -1;
			}

	UCreateShader();

	UCreateBuffers();

	UGenerateTexture();

	//Use the Shader program
	glUseProgram(shaderProgram);

	glClearColor(0.0f, 0.0f, 0.0f, 1.0f); //set background color

	glutDisplayFunc(URenderGraphics);

	glutPassiveMotionFunc(UMouseMove); //detects mouse movement

	glutMainLoop();

	//Destroys buffer objects once used
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO);
	glDeleteBuffers(1, &EBO);

	return 0;
}


/*Resizes the window*/
void UResizeWindow(int w, int h)
{
	WindowWidth = w;
	WindowHeight = h;
	glViewport(0, 0, WindowWidth, WindowHeight);
}


/*Renders graphics*/
void URenderGraphics(void)
{

	glEnable(GL_DEPTH_TEST); //enable z-depth

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //clears the screen

	GLint modelLoc, viewLoc, projLoc, uTextureLoc, fillLightColorLoc, fillLightPositionLoc, keyLightColorLoc, keyLightPositionLoc, viewPositionLoc;

	//glBindVertexArray(VAO); //activate the vertex array object before rendering and transforming them
	glm::mat4 model;
	glm::mat4 view;
	glm::mat4 projection;

	CameraForwardZ = front; //replaces camera forward vector with radians normalized as a unit vector

	//transforms the object
	model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f)); //place the object at the center of the viewport
	model = glm::rotate(model, 45.0f, glm::vec3(0.0f, 1.0f, 0.0f)); //rotate the object 45 degrees on the x
	model = glm::scale(model, glm::vec3(2.0f, 2.0f, 2.0f)); //increase the object size by a scale of 2

	//transform the camera
	view = glm::lookAt(CameraForwardZ, cameraPosition, CameraUpY);

	//creates a perspective projection
	projection = glm::perspective(45.0f, (GLfloat)WindowWidth / (GLfloat)WindowHeight, 0.1f, 100.0f);

	//retrieve and passes transform matrices to the shader program
	//GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
	//GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
	//GLint projLoc = glGetUniformLocation(shaderProgram, "projection");

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Reference matrix uniforms from the pyramid shader
		uTextureLoc = glGetUniformLocation(shaderProgram, "uTexture");
		fillLightColorLoc = glGetUniformLocation(shaderProgram, "fillLightColor");
		fillLightPositionLoc = glGetUniformLocation(shaderProgram, "fillLightPosition");
		keyLightColorLoc = glGetUniformLocation(shaderProgram, "keyLightColor");
		keyLightPositionLoc = glGetUniformLocation(shaderProgram, "keyLightPosition");
		viewPositionLoc = glGetUniformLocation(shaderProgram, "viewPosition");

		// Pass texture, light, and camera data to pyramid shader program
		glUniform1i(uTextureLoc, 0); // texture at point 0
		glUniform3f(fillLightColorLoc, fillLightColor.r, fillLightColor.g, fillLightColor.b);
		glUniform3f(fillLightPositionLoc, fillLightPosition.x, fillLightPosition.y, fillLightPosition.z);
		glUniform3f(keyLightColorLoc, keyLightColor.r, keyLightColor.g, keyLightColor.b);
		glUniform3f(keyLightPositionLoc, keyLightPosition.x, keyLightPosition.y, keyLightPosition.z);
		glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

		// Attach the texture
		glBindTexture(GL_TEXTURE_2D, texture);

		// Draw the triangles
		glDrawArrays(GL_TRIANGLES, 0, 18);

		glBindVertexArray(0); // Deactivate vertex array

		// Use the fill shader and activate its VBO
		glUseProgram(fillShaderProgram);
		glBindVertexArray(FillLightVAO); // Activate the vertex array object

		// Transform the object
		model = glm::translate(model, fillLightPosition); // Place the light
		model = glm::scale(model, fillLightScale); // Scale object by fillLightScale

		// Retrieve and pass transformation matrices to shader
		modelLoc = glGetUniformLocation(fillShaderProgram, "model");
		viewLoc = glGetUniformLocation(fillShaderProgram, "view");
		projLoc = glGetUniformLocation(fillShaderProgram, "projection");

		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

		glDrawArrays(GL_TRIANGLES, 0, 18); // Draw the lamp
		glBindVertexArray(0); // Deactivate the lamp VAO

		// Use the fill shader and activate its VBO
		glUseProgram(keyShaderProgram);
		glBindVertexArray(KeyLightVAO); // Activate the vertex array object

		// Transform the object
		model = glm::translate(model, keyLightPosition); // Place the light
		model = glm::scale(model, keyLightScale); // Scale object by fillLightScale

		// Retrieve and pass transformation matrices to shader
		modelLoc = glGetUniformLocation(keyShaderProgram, "model");
		viewLoc = glGetUniformLocation(keyShaderProgram, "view");
		projLoc = glGetUniformLocation(keyShaderProgram, "projection");

		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

		glDrawArrays(GL_TRIANGLES, 0, 18); // Draw the lamp
		glBindVertexArray(0); // Deactivate the lamp VAO

		glutPostRedisplay(); // Redraw the screen
		glutSwapBuffers(); // Flip the front and back buffers every frame back buffer with the front buffer every frame. Similar to GL flush

}

/*Creates the shader program*/
void UCreateShader()
{

	//vertex shader
	GLint vertexShader = glCreateShader(GL_VERTEX_SHADER); //creates the vertex shader
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL); //attaches the vertex shader to the source code
	glCompileShader(vertexShader); //compiles the vertex shader

	//fragment shader
	GLint keyfragmentShader = glCreateShader(GL_FRAGMENT_SHADER); //creates the fragment shader
	glShaderSource(keyfragmentShader, 1, &keyfragmentShaderSource, NULL); //attaches the fragment shader to the source code
	glCompileShader(keyfragmentShader); //compiles the fragment shader

	//Shader program
	shaderProgram = glCreateProgram(); //create the shader program and return an id
	glAttachShader(shaderProgram, vertexShader); //attach vertex shader to the shader program
	glAttachShader(shaderProgram, keyfragmentShader); //attach fragment shader to the shader program
	glLinkProgram(shaderProgram); //link vertex and fragment shaders to shader program

	//delete the vertex and fragment shaders once linked
	glDeleteShader(vertexShader);
	glDeleteShader(keyfragmentShader);


// Fill light vertex shader
	GLint fillVertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(fillVertexShader, 1, &fillVertexShaderSource, NULL); // Attach the vertex shader
	glCompileShader(fillVertexShader); // Compile the vertex shader

	// Fill light fragment shader
	GLint fillFragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fillFragmentShader, 1, &fillFragmentShaderSource, NULL); // Attach the fragment shader
	glCompileShader(fillFragmentShader); // Compile the fragment shader

	// New shader program
	fillShaderProgram = glCreateProgram(); // Get ID for shader program
	glAttachShader(fillShaderProgram, fillVertexShader); // Attach the vertex shader to the shader program
	glAttachShader(fillShaderProgram, fillFragmentShader); // Attach the fragment shader to the shader program
	glLinkProgram(fillShaderProgram); // Link the vertex and fragment shaders to the shader program

	// Delete shaders once linked
	glDeleteShader(fillVertexShader);
	glDeleteShader(fillFragmentShader);

	// Key light vertex shader
	GLint keyVertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(keyVertexShader, 1, &keyVertexShaderSource, NULL); // Attach the vertex shader
	glCompileShader(keyVertexShader); // Compile the vertex shader

	// Key light fragment shader
	GLint keyFragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(keyFragmentShader, 1, &fillFragmentShaderSource, NULL); // Attach the fragment shader
	glCompileShader(keyFragmentShader); // Compile the fragment shader

	// New shader program
	fillShaderProgram = glCreateProgram(); // Get ID for shader program
	glAttachShader(fillShaderProgram, keyVertexShader); // Attach the vertex shader to the shader program
	glAttachShader(fillShaderProgram, keyFragmentShader); // Attach the fragment shader to the shader program
	glLinkProgram(fillShaderProgram); // Link the vertex and fragment shaders to the shader program

	// Delete shaders once linked
	glDeleteShader(keyVertexShader);
	glDeleteShader(keyFragmentShader);
}


void UCreateBuffers()
{

	GLfloat vertices[] = {
							//Positions           //Normals				//Texture Coordinates
							-0.6f, -0.6f, 0.4f,   0.0f, 0.0f, -1.0f,	0.0f, 0.0f,
							-0.8f, 0.8f, 0.4f,    0.0f, 0.0f, -1.0f, 	1.0f, 0.0f,
							-0.4f, 0.4f, 0.0f,    0.0f, 0.0f, -1.0f,	1.0f, 1.0f,
							1.0f, -1.0f, 0.0f,    0.0f, 0.0f, -1.0f,	0.0f, 1.0f,

							-0.8f, 0.8f, 0.8f,    0.0f, 0.0f, 1.0f,		0.0f, 0.0f,
							-0.8f, 0.8f, 0.3f,    0.0f, 0.0f, 1.0f,		1.0f, 0.0f,
							-0.4f, 0.4f, -0.1f,   0.0f, 0.0f, 1.0f,		1.0f, 1.0f,
							-0.4f, 0.4f, 0.0f,    0.0f, 0.0f, 1.0f,		1.0f, 1.0f,

							-0.4f, 0.4f, 0.0f,    -1.0f, 0.0f, 0.0f,	1.0f, 0.0f,
							-0.4f, 0.4f, -0.1f,   -1.0f, 0.0f, 0.0f,	1.0f, 1.0f,
							1.0f, -1.0f, -0.1f,   -1.0f, 0.0f, 0.0f,	0.0f, 1.0f,
							1.0f, -1.0f, 0.0f,    -1.0f, 0.0f, 0.0f,	0.0f, 1.0f,

							1.0f, -1.0f, -0.1f,   1.0f, 0.0f, 0.0f,		1.0f, 0.0f,
							0.9f, -0.9f, -0.1f,   1.0f, 0.0f, 0.0f,		1.0f, 1.0f,
							0.9f, -0.9f, -0.8f,   1.0f, 0.0f, 0.0f,		0.0f, 1.0f,
							1.0f, -1.0f, -0.8f,   1.0f, 0.0f, 0.0f,		0.0f, 1.0f,

							-0.3f, 0.3f, -0.1f,   0.0f,-1.0f, 0.0f,		0.0f, 1.0f,
							-0.4f, 0.4f, -0.1f,   0.0f,-1.0f, 0.0f,		1.0f, 1.0f,
							-0.4f, 0.4f, -0.8f,   0.0f,-1.0f, 0.0f,		1.0f, 0.0f,
							-0.3f, 0.3f, -0.8f,   0.0f,-1.0f, 0.0f,		1.0f, 0.0f,

							-0.7f, 0.7f, 0.3f,    0.0f, 1.0f, 0.0f,		0.0f, 1.0f,
							-0.8f, 0.8f, 0.3f,    0.0f, 1.0f, 0.0f,		1.0f, 1.0f,
							-0.8f, 0.8f, -0.8f,   0.0f, 1.0f, 0.0f,		1.0f, 0.0f,
							-0.7f, 0.7f, -0.8,    0.0f, 1.0f, 0.0f,		1.0f, 0.0f

					};


		//generate buffer ids
		glGenVertexArrays(1, &VAO);
		glGenBuffers(1, &VBO);

		//activate the vertex array object before binding and setting any vbos and vertex attribute pointers
		glBindVertexArray(VAO);

		//activate the vbo
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); //copy vertices to vbo


		//set attribute pointer 0 to hold position data
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(0); //enables vertex attribute

		//set attribute pointer 1 to hold color data
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(1); //enables vertex attribute

		//set attribute pointer 2 to hold texture coordinate data
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(2);

		glBindVertexArray(0); //deactivates the vao which is good practice.

		// Generate buffer ids for fill light
			glGenVertexArrays(1, &FillLightVAO); // VAO for light source
			glBindVertexArray(FillLightVAO); // Activate the light VAO
			glBindBuffer(GL_ARRAY_BUFFER, VBO); // Reference the same VBO vertices

			// Set attrib pointer at index 0 to hold position data for the fill light
			glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
			glBindVertexArray(0);
}

/*Generate and load the texture*/
void UGenerateTexture(){

		glGenTextures(1, &texture);
		glBindTexture(GL_TEXTURE_2D, texture);

		int width, height;

		unsigned char* image = SOIL_load_image("brick_texture3379.jpg", &width, &height, 0, SOIL_LOAD_RGB); //loads texture file

		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		glGenerateMipmap(GL_TEXTURE_2D);
		SOIL_free_image_data(image);
		glBindTexture(GL_TEXTURE_2D, 0); //unbind the texture
}



/*Implements the UMouseMove function */
void UMouseMove(int x, int y)
{
	//immediately replaces center locked coordinates with new mouse coordinates
	if(mouseDetected)
		{
			lastMouseX = x;
			lastMouseY = y;
			mouseDetected = false;
		}

		//gets the direction the mouse was moved in x and y
		mouseXOffset = x - lastMouseX;
		mouseYOffset = lastMouseY - y; //inverted y

		//updates with new mouse coordinates
		lastMouseX = x;
		lastMouseY = y;

		//applies sensitivity to mouse direction
		mouseXOffset *= sensitivity;
		mouseYOffset *= sensitivity;

		//accumulates the yaw and pitch variables
		yaw += mouseXOffset;
		pitch += mouseYOffset;

		//orbits around the center
		front.x = 10.0f * cos(yaw);
		front.y = 10.0f * sin(pitch);
		front.z = sin(yaw) * cos(pitch) * 10.0f;
}

