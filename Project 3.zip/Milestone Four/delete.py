#!/usr/bin/python
import json
from bson import json_util
import bottle
from bottle import route, run, request, abort
from pymongo import MongoClient


#Establish Connections
connection = MongoClient('localhost', 27017)
db=connection['market']
collection = db['stocks']

#set up URI paths for REST service
@route('/delete', method'GET')
def get_delete():
  global ticker
  request.query.ticker
  ticker=request.query.ticker
  collection.delete_one({"Ticker" : ticker})
  deleted_doc = collection.find_one({"Ticker" : ticker})
  
  if dumps(deleted_doc) == "null"
    return ("\nThe document has been deleted.\n")
  else:
    abort(404, 'Deletion failed')

if __name__ == '__main__':
      #app.run(debug=True)
      run(host='localhost', port=8080)
