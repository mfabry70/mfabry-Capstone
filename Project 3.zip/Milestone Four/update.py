import json
from bson import json_util
from pymongo import MongoClient

connection = MongoClient('localhost', 27017)
db = connection['market']
collection = db['stocks']

def update_document(findDocument, newDocument):
  try: 
    result=collection.update(findDocument, {"$set":newDocument})
    print(json_util.dumps(list(result)))
  except ValidationError as ve:
    abort(400, str(ve))
    print 'Handling exception:', ve
    return False

def main():
  findDocument = {"Ticker":"MF"}
  newDocument = {"Volume":245678}
  print update_document(findDocument,newDocument)
  
main()