import grovepi
import math
import time
from grove_rgb_lcd import *
import json

#Connect the Grove Temperature & Humidity Sensor Pro digital port D4
sensor = 4 #
#The sensor goes on digital port 4

#temp_humidity_sensor_type
blue = 0 # The blue colored sensor

#Adding the data string for json database
data = {}
data['temp_humidity'] = []
     

while True:
    try:
        # This example uses the blue colored sensor
        # The first parameter is the port, the second parameter is the type of sensor
        [temp, humidity] = grovepi.dht(sensor, blue) #Get the temperature and Humidity from the DHT sensor
        

        if math.isnan(temp) == False and math.isnan(humidity) == False:
            temp = ((temp * 9) / 5.0) + 32 #conversion from celsius to fahrenheit
        
            print("temp = %.02f F humidity =%.02f%%"%(temp, humidity))
            t = str(temp)
            h = str(humidity)
        
            setRGB(0, 255, 0) #set color on the backlight to a light blue
            setText("Temp:" + t +"F       " + "Humidity :" + h + "%") #displaying all the data to the backlight
            
            #Adding json print
            data['temp_humidity'].append([temp, humidity])
            
            #Adding json file named data.json
            with open("data.json", "w") as outfile:
                json.dump(data['temp_humidity'], outfile, indent=4)
        
   
        # wait some time before re-updating the LCD
        time.sleep(10.0)
        
    except IOError:
        print("Error")